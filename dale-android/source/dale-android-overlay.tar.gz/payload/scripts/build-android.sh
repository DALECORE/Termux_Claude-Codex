#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SOURCE_DIR="${1:-${TERMUX_SOURCE_DIR:-}}"

if [[ -z "$SOURCE_DIR" || ! -d "$SOURCE_DIR/.git" ]]; then
  echo "Usage: $0 /path/to/termux-app" >&2
  exit 2
fi

SOURCE_DIR="$(cd "$SOURCE_DIR" && pwd)"
# shellcheck disable=SC1091
source "$ROOT_DIR/config/termux-claude.env"

"$SCRIPT_DIR/apply-overlay.sh" "$SOURCE_DIR"

export TERMUX_PACKAGE_VARIANT
export TERMUX_APP_VERSION_NAME
export TERMUX_SPLIT_APKS_FOR_DEBUG_BUILDS

chmod +x "$SOURCE_DIR/gradlew"
cd "$SOURCE_DIR"
./gradlew assembleDebug -x lint --stacktrace

echo
echo "Build complete. APK directory:"
echo "$SOURCE_DIR/app/build/outputs/apk/debug"
find "$SOURCE_DIR/app/build/outputs/apk/debug" -maxdepth 1 -type f -name '*.apk' -print
