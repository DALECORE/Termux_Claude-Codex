#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SOURCE_DIR="${1:-${TERMUX_SOURCE_DIR:-}}"

if [[ -z "$SOURCE_DIR" || ! -d "$SOURCE_DIR/.git" ]]; then
  echo "Usage: $0 /path/to/termux-app" >&2
  exit 2
fi

SOURCE_DIR="$(cd "$SOURCE_DIR" && pwd)"
# shellcheck disable=SC1091
source "$ROOT_DIR/config/termux-claude.env"

actual_commit="$(git -C "$SOURCE_DIR" rev-parse HEAD)"
if [[ "$actual_commit" != "$UPSTREAM_COMMIT" ]]; then
  echo "Refusing to patch unexpected upstream commit." >&2
  echo "Expected: $UPSTREAM_COMMIT" >&2
  echo "Actual:   $actual_commit" >&2
  echo "Checkout the pinned commit first." >&2
  exit 3
fi

JAVA_DEST="$SOURCE_DIR/app/src/main/java/com/termux/app/ClaudeLauncherActivity.java"
SHORTCUTS_DEST="$SOURCE_DIR/app/src/main/res/xml/shortcuts.xml"
ICON_DEST="$SOURCE_DIR/app/src/main/res/drawable/ic_launcher_iq.xml"
MANIFEST="$SOURCE_DIR/app/src/main/AndroidManifest.xml"
STRINGS="$SOURCE_DIR/app/src/main/res/values/strings.xml"

mkdir -p "$(dirname "$JAVA_DEST")" "$(dirname "$SHORTCUTS_DEST")"
cp "$ROOT_DIR/overlay/app/src/main/java/com/termux/app/ClaudeLauncherActivity.java" "$JAVA_DEST"
cp "$ROOT_DIR/overlay/app/src/main/java/com/termux/app/CodeChatActivity.java" "$SOURCE_DIR/app/src/main/java/com/termux/app/CodeChatActivity.java"
cp "$ROOT_DIR/overlay/app/src/main/res/xml/shortcuts.xml" "$SHORTCUTS_DEST"
cp "$ROOT_DIR/overlay/app/src/main/res/drawable/ic_launcher_iq.xml" "$ICON_DEST"

# Use the custom IQ identity for the launcher and permission icons.
sed -i \
  -e 's#android:icon="@mipmap/ic_launcher"#android:icon="@drawable/ic_launcher_iq"#g' \
  -e 's#android:roundIcon="@mipmap/ic_launcher_round"#android:roundIcon="@drawable/ic_launcher_iq"#g' \
  "$MANIFEST"

if ! grep -q 'android:name=".ClaudeLauncherActivity"' "$MANIFEST"; then
  sed -i '/^[[:space:]]*<\/application>[[:space:]]*$/i\
        <activity\
            android:name=".ClaudeLauncherActivity"\
            android:excludeFromRecents="true"\
            android:exported="true"\
            android:noHistory="true" />\
' "$MANIFEST"
fi

if ! grep -q 'android:name=".CodeChatActivity"' "$MANIFEST"; then
  sed -i '/^[[:space:]]*<\/application>[[:space:]]*$/i\
        <activity\
            android:name=".CodeChatActivity"\
            android:exported="true" />\
' "$MANIFEST"
fi

if ! grep -q 'name="shortcut_claude_code"' "$STRINGS"; then
  sed -i '$d' "$STRINGS"
  cat >> "$STRINGS" <<'XML'

    <!-- Termux Claude static shortcuts -->
    <string name="shortcut_claude_code">Claude Code</string>
    <string name="shortcut_claude_code_long">Open Claude Code in Ubuntu</string>
    <string name="shortcut_ubuntu_shell">Ubuntu Shell</string>
    <string name="shortcut_ubuntu_shell_long">Open an Ubuntu login shell</string>

</resources>
XML
fi

echo "Overlay applied successfully to: $SOURCE_DIR"
