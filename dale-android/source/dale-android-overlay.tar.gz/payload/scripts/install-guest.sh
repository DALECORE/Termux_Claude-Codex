#!/data/data/com.termux/files/usr/bin/bash
# Termux Claude Stable - Ubuntu guest provisioning
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck disable=SC1091
source "$ROOT_DIR/config/termux-claude.env"

CONFIG_DIR="$HOME/.config/termux-claude"
LOG_DIR="$HOME/.local/share/termux-claude/logs"
mkdir -p "$CONFIG_DIR" "$LOG_DIR"

log(){ printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"; }
die(){ log "ERROR: $*"; exit 1; }

guest(){
  local command="$1"
  proot-distro login "$DISTRO" -- /bin/bash -lc "export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin; unset LD_PRELOAD PREFIX TERMUX_PREFIX TERMUX_VERSION; $command"
}

command -v proot-distro >/dev/null 2>&1 || die "proot-distro is missing; run install-host.sh first"
proot-distro login "$DISTRO" -- /bin/sh -c 'test -f /etc/os-release && test -d /root' >/dev/null 2>&1 || die "Ubuntu guest is not usable"

log "Updating guest APT metadata"
guest 'DEBIAN_FRONTEND=noninteractive apt-get update'

log "Installing build/runtime prerequisites"
guest 'DEBIAN_FRONTEND=noninteractive apt-get install -y build-essential curl ca-certificates git ripgrep python3'

log "Checking guest Node.js"
node_major="$(guest 'node -v 2>/dev/null || true' | sed -n 's/^v\([0-9][0-9]*\).*/\1/p')"
if [[ ! "$node_major" =~ ^[0-9]+$ || "$node_major" -lt "$NODE_MAJOR" ]]; then
  log "Installing Node.js ${NODE_MAJOR}.x from NodeSource"
  guest "curl -fsSL https://deb.nodesource.com/setup_${NODE_MAJOR}.x | bash -"
  guest 'DEBIAN_FRONTEND=noninteractive apt-get install -y nodejs'
fi

node_v="$(guest 'node -v')"
npm_v="$(guest 'npm -v')"
log "Guest Node: $node_v; npm: $npm_v"

if [[ "$CLAUDE_CODE_VERSION" == "latest" ]]; then
  log "Installing latest Claude Code"
  guest 'npm install -g @anthropic-ai/claude-code'
else
  log "Installing Claude Code ${CLAUDE_CODE_VERSION}"
  guest "npm install -g @anthropic-ai/claude-code@${CLAUDE_CODE_VERSION}"
fi

guest 'mkdir -p /root/.npm'

claude_version="$(guest 'claude --version 2>/dev/null || true')"
claude_path="$(guest 'command -v claude 2>/dev/null || true')"
[[ -n "$claude_path" ]] || die "Claude Code binary was not installed"
[[ -n "$claude_version" ]] || die "Claude Code did not respond to --version"
log "Claude Code: $claude_version"
log "Claude binary: $claude_path"

cat > "$CONFIG_DIR/guest.conf" <<EOF_CONF
DISTRO="$DISTRO"
NODE_MAJOR="$NODE_MAJOR"
CLAUDE_CODE_VERSION="$CLAUDE_CODE_VERSION"
CLAUDE_BINARY="$claude_path"
INSTALLED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
EOF_CONF
chmod 600 "$CONFIG_DIR/guest.conf"
log "Guest provisioning complete. Claude launcher is ready."
